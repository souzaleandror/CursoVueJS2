export default {
    computed: {
        usuarioLogado() {
            return 'Maria Silva'
        }
    },
    created() {
        console.log('Created - Usuario Mixin!')
    }
}