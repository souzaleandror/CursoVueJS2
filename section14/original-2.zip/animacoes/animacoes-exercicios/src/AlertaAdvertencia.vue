<template>
    <b-alert variant="warning" show>Uma mensagem importante!</b-alert>
</template>

<script>
export default {

}
</script>

<style>

</style>
