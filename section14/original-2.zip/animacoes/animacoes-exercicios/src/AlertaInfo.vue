<template>
    <b-alert variant="info" show>Uma mensagem importante!</b-alert>
</template>

<script>
export default {

}
</script>

<style>

</style>
