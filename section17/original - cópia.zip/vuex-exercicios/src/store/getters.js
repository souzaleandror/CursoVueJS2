export const getNome = state => state.nome
export const getNomeCompleto = state => state.nome + state.sobrenome