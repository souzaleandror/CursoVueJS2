<template>
  <div id="app">
    <app-contadores />
    <button>?</button>
  </div>
</template>

<script>
export default {
  
}
</script>

<style>

</style>
