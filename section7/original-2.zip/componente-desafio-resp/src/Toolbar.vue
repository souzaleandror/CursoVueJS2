<template>
    <v-toolbar app>
        <v-toolbar-title class="headline text-uppercase">
            <span>Desafio</span>
            <span class="font-weight-light">Componente</span>
        </v-toolbar-title>
    </v-toolbar>
</template>

<script>
export default {

}
</script>

<style>

</style>
