<template>
    <div class="caixa azul">
        <slot name="conteudo" />
    </div>
</template>

<script>
export default {

}
</script>

<style scoped>

</style>
