<template>
    <div class="caixa vermelho">
        <slot name="conteudo" />
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
